const canvas = document.getElementById("game") as HTMLCanvasElement;
const ctx = canvas.getContext("2d")!;
const vibesEl = document.getElementById("vibes")!;
const speedEl = document.getElementById("speed")!;
const statusEl = document.getElementById("status")!;
const chillBtn = document.getElementById("chillBtn") as HTMLButtonElement;
const resetBtn = document.getElementById("resetBtn") as HTMLButtonElement;

const DPR = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
function resize() {
  const rect = canvas.getBoundingClientRect();
  canvas.width = Math.floor(rect.width * DPR);
  canvas.height = Math.floor((rect.width * 0.58) * DPR);
}
resize();
addEventListener("resize", resize);

type Vec = { x: number; y: number };
let pos: Vec = { x: canvas.width * 0.5, y: canvas.height * 0.5 };
let vel: Vec = { x: 2.5, y: 2.0 };
let radius = Math.max(18 * DPR, Math.min(canvas.width, canvas.height) * 0.05);
let chill = false;
let vibes = 0;

const phrases = [
  "so chill. much ball.",
  "staking? nah, vibing.",
  "blue ball > bull run",
  "HODL the vibes",
  "utility: spherical"
];
let phrase = phrases[Math.floor(Math.random() * phrases.length)];
let phraseTimer = 0;

function rand(min: number, max: number) { return Math.random() * (max - min) + min; }

function drawBall() {
  const g = ctx.createRadialGradient(pos.x - radius * 0.4, pos.y - radius * 0.5, radius * 0.1,
    pos.x, pos.y, radius * 1.2);
  g.addColorStop(0, "#6aa7ff");
  g.addColorStop(1, "#0a58ff");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(pos.x, pos.y, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(pos.x - radius * 0.35, pos.y - radius * 0.4, radius * 0.35, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(255,255,255,0.18)";
  ctx.fill();
  if (chill) {
    const w = radius * 1.2; const h = radius * 0.45; const y = pos.y - radius * 0.2; const x = pos.x - w / 2;
    ctx.fillStyle = "#111827";
    ctx.fillRect(x, y, w * 0.42, h);
    ctx.fillRect(x + w * 0.58, y, w * 0.42, h);
    ctx.fillRect(x + w * 0.42, y + h * 0.35, w * 0.16, h * 0.2);
    ctx.fillStyle = "rgba(255,255,255,0.25)";
    ctx.fillRect(x + 6 * DPR, y + 6 * DPR, 8 * DPR, 8 * DPR);
  }
}

function drawScene() {
  ctx.fillStyle = "#0b1020";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "rgba(13, 19, 41, 0.5)";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  drawBall();
  ctx.font = `${16 * DPR}px ui-sans-serif, system-ui, Segoe UI, Roboto`;
  ctx.fillStyle = "rgba(155, 179, 255, 0.9)";
  ctx.textAlign = "center";
  ctx.fillText(phrase, pos.x, pos.y + radius + 22 * DPR);
}

function step() {
  const speedMul = chill ? 0.45 : 1;
  pos.x += vel.x * speedMul * DPR;
  pos.y += vel.y * speedMul * DPR;
  if (pos.x < radius || pos.x > canvas.width - radius) { vel.x *= -1; pos.x = Math.max(radius, Math.min(canvas.width - radius, pos.x)); }
  if (pos.y < radius || pos.y > canvas.height - radius) { vel.y *= -1; pos.y = Math.max(radius, Math.min(canvas.height - radius, pos.y)); }
  phraseTimer += 1;
  if (phraseTimer > 180) { phrase = phrases[Math.floor(Math.random() * phrases.length)]; phraseTimer = 0; }
}

function loop() { step(); drawScene(); requestAnimationFrame(loop); }

canvas.addEventListener("click", (e) => {
  const rect = canvas.getBoundingClientRect();
  const x = (e.clientX - rect.left) * DPR;
  const y = (e.clientY - rect.top) * DPR;
  const dx = x - pos.x; const dy = y - pos.y;
  if (Math.hypot(dx, dy) <= radius * 1.2) {
    vibes++; vibesEl.textContent = String(vibes);
    vel.x += rand(-0.8, 0.8); vel.y += rand(-0.8, 0.8);
    statusEl.textContent = "vibe tapped";
  } else { statusEl.textContent = "missed, still chill"; }
});

chillBtn.addEventListener("click", () => {
  chill = !chill;
  chillBtn.textContent = `Chill Mode: ${chill ? "ON" : "OFF"}`;
  statusEl.textContent = chill ? "chilling 😎" : "coasting";
  speedEl.textContent = chill ? "0.45x" : "1.0x";
});

resetBtn.addEventListener("click", () => {
  pos = { x: canvas.width * 0.5, y: canvas.height * 0.5 };
  vel = { x: 2.5, y: 2.0 }; vibes = 0;
  vibesEl.textContent = "0"; statusEl.textContent = "reset";
});

loop();